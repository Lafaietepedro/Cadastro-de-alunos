const Navbar = () => {
  return (
    <nav>
      <h1>Cadastro de Alunos</h1>
    </nav>
  );
};

export default Navbar;
